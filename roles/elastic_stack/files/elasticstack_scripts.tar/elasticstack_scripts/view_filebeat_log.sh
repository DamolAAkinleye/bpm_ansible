#!/bin/bash

sudo tail -f /var/log/filebeat/filebeat
