#!/bin/bash
sudo systemctl $1 logstash
