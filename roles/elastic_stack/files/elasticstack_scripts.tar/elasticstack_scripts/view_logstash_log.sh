#!/bin/bash

sudo tail -f /var/log/logstash/logstash-plain.log
